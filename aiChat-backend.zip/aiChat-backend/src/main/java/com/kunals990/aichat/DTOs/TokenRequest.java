package com.kunals990.aichat.DTOs;

import lombok.Data;

@Data
public class TokenRequest {
    private String token;
}
