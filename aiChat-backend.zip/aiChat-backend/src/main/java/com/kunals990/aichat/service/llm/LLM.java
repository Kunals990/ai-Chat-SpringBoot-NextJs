package com.kunals990.aichat.service.llm;

public interface LLM{
    String getResponse(String prompt);
}
